{
  "type": "minecraft:crafting_shaped",
  "category": "equipment",
  "key": {
    "#": {
      "item": "minecraft:stick"
    },
    "X": {
      "item": "minecraft:diamond"
    }
  },
  "pattern": [
    "X",
    "X",
    "#"
  ],
  "result": {
    "count": 1,
    "id": "ncngamer-sword:ncngamer_sword"
  }
}
